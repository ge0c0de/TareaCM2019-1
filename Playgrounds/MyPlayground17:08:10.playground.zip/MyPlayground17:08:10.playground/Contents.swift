//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"


struct Track{
    var trackNumber: Int
}
let tracks = [Track(trackNumber: 3), Track(trackNumber: 2),Track(trackNumber: 1), Track(trackNumber: 4)]

let sortedTracks = tracks.sorted {
    $0.trackNumber < $1.trackNumber
}



let names = ["Marduk", "Adriana", "Rodrigo", "Samanta"]
var fullNames : [String] = []
var fullNames2 : [String] = []

for name in names{
    let fullName = name + "Perez"
    fullNames.append(fullName)
}

fullNames2 = names.map { (cadena) in
    return cadena + " Perez"
}
print(fullNames2)


let numbers = [4,8,15,16,32,54,2,5,8]

let filtro = numbers.filter { (numero) -> Bool in
    return numero < 20
}

let reductor = numbers.reduce(0) { (actual, siguienteValor) -> Int in
    return actual + siguienteValor
}
print(reductor)

let reductor2 = numbers.reduce(0)  {$0 + $1})
print(reductor2)

print(filtro)
