import UIKit
import Foundation

//var str = "Hello, playground"
let jsonFromWeb = """
{
"firstName": "Omar",
"lastName": Viveros",
"jobTitle": "Student"
"phoneNumber": "5516151287"

}
""".data(using: .utf8)!

struct Employee: Decodable, Encodable {
    var firstName: String
    var lastName: String
    var jobTitle: String
    var phoneNumber: String
}


let jsonDecoder = JSONDecoder()

if let result = try? jsonDecoder.decode(Employee.self, from: jsonFromWeb){
    print(result)
    var resultMod = result
    resultMod.firstName = "Marco"
    print(resultMod)
    print(result)
    let myencode = try JSONEncoder().encode(resultMod)
    print(myencode)
}
else{

    print("Falló Decode")
}

