import UIKit

extension URL{
    func withQueries(_ queries: [String:String]) -> URL?{
        var components = URLComponents(url: self, resolvingAgainstBaseURL: true)
        components?.queryItems = queries.map{
            URLQueryItem(name: $0.0, value: $0.1)
        }
        return components?.url
    }
}

let baseUrl = URL(string: "https://api.nasa.gov/planetary/apod")!
let query: [String:String] = ["api_key":"TgtNnpcTGB30H5gKn6uqbKHUflu7yAaJKtuyQUnq","date":"2013-07-13"]

struct NasaPhoto: Codable {
    var date: String
    var title: String
    var explanation: String
    var url: String
    enum CodingKeys: String,CodingKey {
        case date
        case titulo = "title"
        case explanation
        case url
    }
    
} //pag 856


let url = baseUrl.withQueries(query)!

let task = URLSession.shared.dataTask(with: url) { (data, response, error) in
    if let data = data, //se compara si data no quedó vacia
        let string = String(data: data, encoding: .utf8){
            print(string)
        }
        
            //print(data as? NSData)
        
    
}
task.resume()    //se manda a llamar la tarea que se configuró

